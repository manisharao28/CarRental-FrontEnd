import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-git-auth',
  templateUrl: './git-auth.component.html',
  styleUrls: ['./git-auth.component.css']
})
export class GitAuthComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
