import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router'; 
import { CarrentalService } from '../carrental.service';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  constructor(private http: HttpClient,private router: Router, private route: ActivatedRoute,private carservice:CarrentalService) { }

  ngOnInit(): void {
   
  }


  navigation(num:number){
    let token:any=sessionStorage.getItem( "token" ) 
    switch(num) { 
        case 1: { 
            this.router.navigate(['home']); 
           break; 
        } 
        case 2: { 
          if(token =! ""){
            this.http.get('http://localhost:4000/carlist').subscribe((data : any) => {        
              this.carservice.setCarList(data)
            }); 
          this.router.navigate(['carlist']);
          }
           
           break; 
        } 
        case 3: { 
            this.router.navigate(['booking']); 
            break; 
        }
        case 4: { 
            this.router.navigate(['aboutus']);
            break; 
        } 
        case 5: { 
            this.router.navigate(['contactus']);
            break; 
        }   
        case 6: { 
          sessionStorage.clear();
          this.router.navigate(['login']);
          break; 
      }         
        default: { 
            this.router.navigate(['home']);
           break; 
        } 
     } 
    
  }
}
