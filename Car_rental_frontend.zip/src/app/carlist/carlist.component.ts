import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http' 
import { CarlistElement } from '../../models/carlistModel'
import { CarrentalService } from '../carrental.service';
import { FormBuilder } from '@angular/forms';


@Component({
  selector: 'app-carlist',
  templateUrl: './carlist.component.html',
  styleUrls: ['./carlist.component.css']
})
export class CarlistComponent implements OnInit {
 
  carlists=new Set<CarlistElement>();
  carCategory:any
  carType:any
  FilterForm=this.formBuilder.group({categoryId:0, cartypeId:0});
  constructor(private router: Router,private route: ActivatedRoute,
    private carservice:CarrentalService,
    private http: HttpClient,private formBuilder: FormBuilder) {      
     }

  ngOnInit(): void {    
    
    this.http.get('http://localhost:4000/carlist').subscribe((data : any) => {        
      this.carlists =data  
      this.carservice.setCarList(data)      
    }); 
    this.http.get('http://localhost:4000/carCategory').subscribe((data : any) => {        
        this.carCategory=data       
    });   
    this.http.get('http://localhost:4000/carType').subscribe((data : any) => {        
      this.carType=data       
    }); 
    //this.carCategory=[{Crgry_Id:1,Crgry_Name:'BMW'},{Crgry_Id:1,Crgry_Name:'Audi'},{Crgry_Id:1,Crgry_Name:'Lexsus'}]
    //this.carType=[{CrTyp_Id:1,CrTyp_Name:'Coupe'},{CrTyp_Id:1,CrTyp_Name:'SUV'},{CrTyp_Id:1,CrTyp_Name:'Sedan'}]
    // JSON.parse(this.route.snapshot.paramMap.get('my_object') || '{}');
  }
  onCarInterest(name:string,id:number){
    this.carservice.setCarNameId(name,id)
    this.router.navigate(['booking']);
  }
  pagination(pageSt:number,pageEd:number){
    this.http.post('http://localhost:4000/page',{pageStart:pageSt,pageEnd:pageEd}).subscribe((data : any) => {        
        this.carlists=data       
      }); 
  }

  sorting(data:Boolean){
    this.http.post('http://localhost:4000/sortPrice',{hightoLow:data}).subscribe((data : any) => {        
        this.carlists=data       
      }); 
  }
  onFiltering(){
    let catypId=(this.FilterForm.value.cartypeId==undefined)?0:this.FilterForm.value.cartypeId;
    let catId=(this.FilterForm.value.categoryId==undefined)?0:this.FilterForm.value.categoryId;
    this.http.post('http://localhost:4000/carFilter',{categoryId:catId, cartypeId:catypId}).subscribe((data : any) => {        
      this.carlists=data       
    }); 
  }

  clearFilter(){
    this.http.get('http://localhost:4000/carlist').subscribe((data : any) => {        
      this.carlists=data       
    }); 
  }

}
