import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { HttpClient } from '@angular/common/http'
import { Router, ActivatedRoute } from '@angular/router'; 
import { CarrentalService } from '../carrental.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  show:Boolean=true
  AuthUrl:string=""
  checkoutForm = this.formBuilder.group({
    name: '',
    email: '',
    password:'',
    rePassword:'',
    condition:false
  });
  constructor(private formBuilder: FormBuilder,private http: HttpClient,private router: Router, private route: ActivatedRoute,private carservice:CarrentalService) { }
  
  ngOnInit(): void {
    this.show=true
    this.carservice.GetAuthPage().subscribe((data:any)=>
      this.AuthUrl=data.authUrl
      );
  }
  loginWithGithub()
  {        
    this.carservice.loginGit=true
    this.router.navigate(['/test'],{queryParams:{url:this.AuthUrl}});
  }
  onLoginChange(){
    this.show=false
  }

  onSubmit(): void {
    // Process checkout data here
    
    if(this.checkoutForm.value.email!=''){
      this.http.post('http://localhost:4000/register',{name:this.checkoutForm.value.name,email:this.checkoutForm.value.email,password:this.checkoutForm.value.password})
      .subscribe((data : any) => {        
        if(data.register){
          this.router.navigate(['home']);
        }
        this.checkoutForm.reset();
      }); 
    }else{
      this.http.post('http://localhost:4000/login',{name:this.checkoutForm.value.name,password:this.checkoutForm.value.password})
      .subscribe((data : any) => {  
        sessionStorage.setItem("token", data.token);
        sessionStorage.setItem("user", JSON.stringify(data.user));
        this.router.navigate(['home']);        
        this.checkoutForm.reset();
      }); 
    }
    
    //console.log(this.checkoutForm.value)   
    //console.warn('Your order has been submitted', this.checkoutForm.value);
    
  }
}
