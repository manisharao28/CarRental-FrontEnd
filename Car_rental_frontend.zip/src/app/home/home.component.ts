import { Component, OnInit } from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import { CarrentalService } from '../carrental.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  username:any="";
  constructor(private active:ActivatedRoute,private serv:CarrentalService,private router:Router) { }

  ngOnInit(): void {    
    
    if(this.serv.loginGit){
      this.serv.getUserDetails().subscribe((data:any)=>
      this.username=data.login
      ,err=>{console.log(err)});
    }else{
      let temp=JSON.parse(sessionStorage.getItem("user")|| "")
      this.username=temp.foundId
    }    

  }
 

}
