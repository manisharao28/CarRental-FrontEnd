import { Injectable } from '@angular/core';
import { CarlistElement } from '../models/carlistModel';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CarrentalService {
  CarList=new Set<CarlistElement>();
  CarName:string=""
  carId:number=0
  loginGit=false
  constructor(private http: HttpClient) { }

  setCarList(data:any){
    this.CarList=data
  }
  getCarList(){
    return this.CarList
  }

  setCarNameId(name:string,id:number){
    this.CarName=name
    this.carId=id
  }
  getCarNameId(){
    return {CarName:this.CarName,carId:this.carId}
  }
  
GetAuthPage()
{
    return this.http.get('http://localhost:4000/oauth/AuthPage');
}

getAcessToken(auth_code:string)
{
  return this.http.post('http://localhost:4000/oauth/getAccessToken',{code:auth_code});

}

getUserDetails()
{
  return this.http.get('http://localhost:4000/oauth/getUserDetails');

}

logout()
{
  return this.http.get('http://localhost:4000/oauth/logout');
 
}




}
