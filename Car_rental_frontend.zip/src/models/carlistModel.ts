export interface CarlistElement {
    CrMod_Id:number;
    CrMod_Name:string;
    CrTyp_Name: string;
    CrMod_img: string;
    CrMod_price: number;
    Crgry_Name: string;
    CrTyp_Id:number;
    Crgry_Id:number;
  
  }