import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-contactus',
  templateUrl: './contactus.component.html',
  styleUrls: ['./contactus.component.css']
})
export class ContactusComponent implements OnInit {
  checkoutForm = this.formBuilder.group({    
    fullname: '',    
    email:'',
    desc:''   
  });

  constructor(private formBuilder: FormBuilder,private http: HttpClient) { }

  ngOnInit(): void {
  }
  onSubmitDetails(){      
    this.http.post('http://localhost:4000/contactDet',{name:this.checkoutForm.value.fullname,
    email:this.checkoutForm.value.email,
    desc:this.checkoutForm.value.desc }).subscribe((data : any) => {                       
    });
    this.checkoutForm.reset();
    alert("Thank you for Contacting !!!")
  }

}
