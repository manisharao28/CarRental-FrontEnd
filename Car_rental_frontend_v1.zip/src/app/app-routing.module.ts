import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutusComponentComponent } from './aboutus-component/aboutus-component.component';
import { CarbookingComponent } from './carbooking/carbooking.component';
import { CarlistComponent } from './carlist/carlist.component';
import { ContactusComponent } from './contactus/contactus.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { RedirectComponent } from './redirect/redirect.component';
import { ExtUrlResolverService } from './ext-url-resolver.service';
import { GitAuthComponent } from './git-auth/git-auth.component';

const routes: Routes = [
  {path: 'aboutus', component: AboutusComponentComponent},
  {path: 'test', component: GitAuthComponent, resolve: {
    url: ExtUrlResolverService
}},
  {path: 'carlist', component: CarlistComponent},
  {path: 'home', component: HomeComponent},
  {path: 'login', component: LoginComponent},  
  {path: 'booking', component: CarbookingComponent}, 
  {path: 'contactus', component: ContactusComponent},  
  {path: 'redirect', component: RedirectComponent},  

  {path: '', redirectTo: '/login', pathMatch: 'full'},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
