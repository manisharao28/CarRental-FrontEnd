import { Component, OnInit } from '@angular/core';
import { CarrentalService } from '../carrental.service';
import { ActivatedRoute, Router } from '@angular/router';
import { concatMap } from 'rxjs/operators';

@Component({
  selector: 'app-redirect',
  templateUrl: './redirect.component.html',
  styleUrls: ['./redirect.component.css']
})
export class RedirectComponent implements OnInit {

  constructor(private active:ActivatedRoute,private serv:CarrentalService,private router:Router) { }

  ngOnInit(): void {
    this.active.queryParamMap.pipe(concatMap(x=>this.serv.getAcessToken(x.get('code') as string) ))
    .subscribe(data=>this.router.navigate(['/home']),err=>{console.log(err)}); 

  }

}
