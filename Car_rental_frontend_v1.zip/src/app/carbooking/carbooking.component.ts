import { Component, OnInit } from '@angular/core';
import {FormGroup, FormControl} from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { CarrentalService } from '../carrental.service';
import { Router } from '@angular/router';

const today = new Date();
const month = today.getMonth();
const year = today.getFullYear();
@Component({
  selector: 'app-carbooking',
  templateUrl: './carbooking.component.html',
  styleUrls: ['./carbooking.component.css']
})
export class CarbookingComponent implements OnInit {
  carDetails = {CarName:"",carId:0}
  Booking:Boolean=true;
  campaignOne = new FormGroup({
    start: new FormControl(new Date(year, month, 13)),
    end: new FormControl(new Date(year, month, 16)),
  });
  campaignTwo = new FormGroup({
    start: new FormControl(new Date(year, month, 15)),
    end: new FormControl(new Date(year, month, 19)),
  });

  checkoutForm = this.formBuilder.group({    
    fname: '',
    lname: '',
    email:'',
    pickupaddr:'',
    dropoffaddr:'',
    tripdate:this.campaignTwo.value.start+'-'+this.campaignTwo.value.end,   
  });

  constructor(private router: Router,private formBuilder: FormBuilder,private http: HttpClient,private service:CarrentalService) { }

  ngOnInit(): void {
    this.carDetails=this.service.getCarNameId()
    console.log(this.carDetails)
    this.Booking=(this.carDetails.carId != 0)? true:false;
  }

  routocarlst(){
    this.router.navigate(['carlist']);
  }
  onTripBooking(){       
    let tripStartDate=this.formatDate(this.campaignTwo.value.start)
    let tripEndDate=this.formatDate(this.campaignTwo.value.end)
    
   
    this.http.post('http://localhost:4000/tripbook',{fname:this.checkoutForm.value.fname,
    lname:this.checkoutForm.value.lname,email:this.checkoutForm.value.email,
    pickupaddr:this.checkoutForm.value.pickupaddr,dropoffaddr:this.checkoutForm.value.dropoffaddr,
    tripdate:this.checkoutForm.value.tripdate,carId:this.carDetails.carId }).subscribe((data : any) => {        
               
    });
    this.checkoutForm.reset();
  }
  formatDate(date:any){
    return (date.getMonth() + 1) + '/' + date.getDate() + '/' +  date.getFullYear()
  }
}
